import { __ } from '@wordpress/i18n';
import { useBlockProps, InspectorControls } from '@wordpress/block-editor';
import { PanelBody } from '@wordpress/components';
import './editor.scss';

/**
 * The edit component for Math Rock.
 *
 * @param {Object} props            - Block props.
 * @param {Object} props.attributes - Block attributes.
 * @param {Function} props.setAttributes - Attribute setter.
 * @return {JSX.Element} Block editor UI.
 */
export default function Edit( { attributes, setAttributes } ) {
	const blockProps = useBlockProps();
	const { num1, num2 } = attributes;

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Settings', 'flexy_plugins' ) }>
					{ /* Add controls here */ }
				</PanelBody>
			</InspectorControls>

			<div { ...blockProps }>
			{ /* Block content */ }
			</div>
		</>
	);
}
