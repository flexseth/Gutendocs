import { useBlockProps } from '@wordpress/block-editor';


/**
 * The save component for Math Rock.
 *
 * @param {Object} props            - Block props.
 * @param {Object} props.attributes - Block attributes.
 * @return {JSX.Element} Saved block markup.
 */
export default function save( { attributes } ) {
	const blockProps = useBlockProps.save();
	const { num1, num2 } = attributes;

	return (
		<div { ...blockProps }>
			{ /* Saved content */ }
		</div>
	);
}
